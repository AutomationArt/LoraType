# 中文说明

* `DEPG0150BxS810FxX_BW ` , `DEPG0213Bx800FxX_BW`,  `DEPG0290BxS75AFxX_BW`,  `QYEG0213RWS800_BWR` 示例只需要引用对应名字的文件及其`picture.h `和`EpdBase.<x>` 。
* 其余文件皆为`e_ink` 示例所需要的文件。

### 更新说明

| Content                                                      | Date       |
| ------------------------------------------------------------ | ---------- |
| 添加新的`DEPG0290BxS800FxX_BW`（注：原`DEPG0290BxS75AFxX_BW`的版本升级，**不兼容**） | 2020/10/29 |





# English description

* `DEPG0150BxS810FxX_BW ` , `DEPG0213Bx800FxX_BW`,  `DEPG0290BxS75AFxX_BW`,  `QYEG0213RWS800_BWR`  examples only need to refer to the corresponding name file and its `picture.h ` and `EpdBase.<x>`.
* The rest of the files are required by `e_ink` example.

### Update description

| Content                                                      | Date       |
| ------------------------------------------------------------ | ---------- |
| Add new version `DEPG0290BxS800FxX_BW` (Remarks: The original version of `DEPG0290BxS75AFxX_BW`is upgraded. **The two versions are incompatible**.) | 2020/10/29 |

